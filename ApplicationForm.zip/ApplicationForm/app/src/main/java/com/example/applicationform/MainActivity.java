package com.example.applicationform;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    String[] countries = {"India", "USA", "UK", "Australia", "Europe", "Netherlands", "South Africa", "Germany",
    " Italy", "Sri Lanka", "Pakistan", "Dubai", "Nepal", "Bhutan", "Bangladesh"};

    Spinner S, S1;
    EditText etFirstName, etLastName, etEmail, etPassword;
    TextView t1, t2;
    Button bCancel, bProceed;

    boolean isAllFieldsChecked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t1 = findViewById(R.id.textView);
        S = findViewById(R.id.spinner);
        t2 = findViewById(R.id.textView2);
        S1 = findViewById(R.id.spinnerState);
        S.setOnItemSelectedListener(this);
        etFirstName = findViewById(R.id.FirstName);
        etLastName = findViewById(R.id.LastName);
        etEmail = findViewById(R.id.Email);
        etPassword = findViewById(R.id.Password);
        bCancel = findViewById(R.id.cancelButton);
        bProceed = findViewById(R.id.proceedButton);

        bProceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isAllFieldsChecked = CheckAllFields();

            }
        });

        bCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.finish();
                System.exit(0);
            }
        });

        etEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = etEmail.getText().toString().trim();
                String RegExp = "^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                        +"((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                        +"[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                        +"([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                        +"[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                        +"([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$";

                if(email.matches(RegExp) && email.length() > 0){
                    Toast.makeText(getApplicationContext(), "Valid Email", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(getApplicationContext(), "Invalid Email", Toast.LENGTH_LONG).show();
                }
            }
        });

        ArrayAdapter a = new ArrayAdapter(this, android.R.layout.simple_spinner_item, countries);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        S.setAdapter(a);
    }

    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {
        Toast.makeText(getApplicationContext(), countries[position], Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {

    }
    private boolean CheckAllFields(){
        if(etPassword.length() == 0){
            etPassword.setError("Password is required");
            return false;
        }
        else if(etPassword.length()<8){
            etPassword.setError("Password must contain minimum 8 characters");
            return false;
        }
        return true;
    }


}