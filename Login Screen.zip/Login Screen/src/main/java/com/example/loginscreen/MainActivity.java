package com.example.loginscreen;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText e1, e2;
    Button b, b1, b2;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1 = findViewById(R.id.etName);
        e2 = findViewById(R.id.etPswrd);
        b = findViewById(R.id.button);
//        b1 = findViewById(R.id.facebook);
        Button b1 = (Button)findViewById(R.id.facebook);
        b1.setOnClickListener(facebook);
//        b2 = findViewById(R.id.google);
        Button english = (Button)findViewById(R.id.google);
        english.setOnClickListener(google);
//        b1.setOnClickListener(facebook);
        b2 = findViewById(R.id.forgotPassword);
    }
    public void login(View v){
        String eName, ePass;
        eName = e1.getText().toString();
        ePass = e2.getText().toString();
        if(ePass.isEmpty()){
            AlertDialog.Builder builder =new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Password");
            builder.setMessage("This field i is mandatory");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Toast.makeText(getApplicationContext(),"OK",Toast.LENGTH_LONG).show();
                    dialogInterface.cancel();
                }
            });
            builder.create();
            builder.show();
        }
        else{
            Toast.makeText(getApplicationContext(),"Welcome back "+eName, Toast.LENGTH_LONG).show();
        }
    }

    private Button.OnClickListener facebook = new View.OnClickListener()
    {
        public void onClick(View v){
            Uri uri = Uri.parse("http://www.facebook.com");
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(i);
        }
    };
    private Button.OnClickListener google
            = new Button.OnClickListener(){

        public void onClick(View v) {

            Uri uri = Uri.parse("http://www.google.com");
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);


        }

    };


}